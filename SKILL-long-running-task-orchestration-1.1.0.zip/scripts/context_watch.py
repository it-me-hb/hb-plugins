#!/usr/bin/env python3
"""
context_watch.py: watch the context size of every agent in a Claude Code session.

Reads the session's transcript files and does not touch the agents. Standard library only.

Where transcripts live:
  ~/.claude/projects/<project-slug>/<session-id>.jsonl                      main session
  ~/.claude/projects/<project-slug>/<session-id>/subagents/agent-<id>.jsonl  every subagent, any depth
  ~/.claude/projects/<project-slug>/<session-id>/subagents/agent-<id>.meta.json
      {agentType, description, toolUseId, spawnDepth, model, ...}

Context size = the last assistant turn's input_tokens + cache_creation_input_tokens
+ cache_read_input_tokens. This is what the model saw on that turn.

Parent = the transcript that contains the Agent tool_use whose id is in the meta file's
toolUseId. That's the agent that spawned this one, and the one that must restart it.
"?" = not resolvable yet (the meta file or the parent's tool_use isn't written yet).

State lives in <dir>/.scratch/supervisor-state.json. <dir> = --dir, else $SUPERVISE_DIR,
else cwd. Run every command from the same project dir, or set SUPERVISE_DIR.

Commands:
  init [--threshold N]   Create .scratch/ with a headed ledger.md, handoffs/, roles/ (worker and
                         orchestrator roles) and templates/. Stores the threshold.
                         Safe to re-run; never overwrites existing files.
  status [--json] [--live]
                         One line per agent (id, parent, depth, tokens, idle, name).
  watch                  Block until one or more agents cross the threshold or go stale,
                         or until --max-wait. Print one JSON line per event, then exit.
                         Run it in the background (Monitor tool, or background Bash).
  ack ID [ID...]         Mark agents as handled so watch stops reporting them.
  verify-handoff PATH --since EPOCH
                         Check that a handoff file exists, was written after EPOCH
                         (`date +%s`), and has the required sections. Exit 0 ok, 1 not ok.

Exit codes for watch: 0 = events printed, 2 = max-wait reached with no event (heartbeat).
"""
from __future__ import annotations

import argparse
import contextlib
import fcntl
import json
import os
import re
import sys
import time
from pathlib import Path

PROJECTS = Path(os.environ.get("CLAUDE_CONFIG_DIR", Path.home() / ".claude")) / "projects"
DEFAULT_THRESHOLD = 500_000
HANDOFF_SECTIONS = ["## State", "## Next", "## Verify first"]
TEMPLATES = Path(__file__).resolve().parent.parent / "templates"
PARENT_RETRY_SECS = 300
BASE_DIR = Path.cwd()                                  # set in main()
STATE_FILE = BASE_DIR / ".scratch" / "supervisor-state.json"


# --- session discovery ------------------------------------------------------

def project_dir(cwd: str) -> Path:
    return PROJECTS / re.sub(r"[^A-Za-z0-9]", "-", cwd)


def _mtime(p: Path) -> float:
    try:
        return p.stat().st_mtime
    except OSError:
        return 0.0


def find_session(session: str | None, cwd: str) -> Path:
    """Return the main transcript path for the session."""
    if session:  # explicit: must match
        hits = list(PROJECTS.glob(f"*/{session}.jsonl"))
        if not hits:
            sys.exit(f"session {session} not found under {PROJECTS}")
        return hits[0]
    env_session = os.environ.get("CLAUDE_CODE_SESSION_ID")
    if env_session:
        hits = list(PROJECTS.glob(f"*/{env_session}.jsonl"))
        if hits:
            return hits[0]
    pdir = project_dir(cwd)
    candidates = sorted(pdir.glob("*.jsonl"), key=_mtime, reverse=True)
    if not candidates:
        sys.exit(f"no transcripts in {pdir} - pass --session <id> or --cwd <dir the session started in>")
    return candidates[0]  # most recently active session = the supervisor's own


# --- transcript parsing -----------------------------------------------------

def context_tokens(u: dict) -> int:
    return (u.get("input_tokens", 0)
            + u.get("cache_creation_input_tokens", 0)
            + u.get("cache_read_input_tokens", 0))


def _usage_from_tail(path: Path, tail_bytes: int | None) -> dict | None:
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            if tail_bytes is not None:
                f.seek(max(0, size - tail_bytes))
            # split on \n only: str.splitlines() also splits on U+2028 etc. inside JSON strings
            lines = f.read().decode("utf-8", "replace").split("\n")
    except OSError:
        return None
    for line in reversed(lines):
        if '"usage"' not in line:
            continue
        try:
            d = json.loads(line)
        except json.JSONDecodeError:
            continue  # partial first line from the seek, or a line being written
        u = (d.get("message") or {}).get("usage")
        if d.get("type") == "assistant" and u and context_tokens(u) > 0:
            return u
    return None


def last_usage(path: Path) -> dict | None:
    """Usage from the last real assistant turn. Reads the tail; whole file if that finds nothing."""
    return _usage_from_tail(path, 512_000) or _usage_from_tail(path, None)


def _file_contains(path: Path, needle: bytes) -> bool:
    try:
        with open(path, "rb") as f:
            return any(needle in line for line in f)
    except OSError:
        return False


def find_parent(tool_use_id: str, transcripts: dict[str, Path], state: dict) -> str:
    """Return the id of the agent whose transcript holds this Agent tool_use, or '?'."""
    if not tool_use_id:
        return "?"
    parents, misses = state["parents"], state["parent_misses"]
    if tool_use_id in parents:
        return parents[tool_use_id]
    if time.time() - misses.get(tool_use_id, 0) < PARENT_RETRY_SECS:
        return "?"
    needle = tool_use_id.encode()
    for aid, path in transcripts.items():
        if _file_contains(path, needle):
            parents[tool_use_id] = aid
            misses.pop(tool_use_id, None)
            return aid
    misses[tool_use_id] = time.time()
    return "?"


def agents(main: Path, state: dict) -> list[dict]:
    rows: list[tuple[str, Path, dict]] = [("main", main, {})]
    sub_dir = main.with_suffix("") / "subagents"
    for t in sorted(sub_dir.rglob("agent-*.jsonl")) if sub_dir.is_dir() else []:
        try:
            meta = json.loads(t.with_name(t.stem + ".meta.json").read_text())
        except (OSError, json.JSONDecodeError):
            meta = {}
        rows.append((t.stem.removeprefix("agent-"), t, meta))
    transcripts = {aid: p for aid, p, _ in rows}
    now = time.time()
    out = []
    for aid, path, meta in rows:
        u = last_usage(path)
        others = {k: v for k, v in transcripts.items() if k != aid}
        out.append({
            "id": aid,
            "name": meta.get("name") or meta.get("description") or ("supervisor" if aid == "main" else ""),
            "parent": "" if aid == "main" else find_parent(meta.get("toolUseId", ""), others, state),
            "type": meta.get("agentType", ""),
            "depth": meta.get("spawnDepth", 0),
            "tokens": context_tokens(u) if u else 0,
            "idle_mins": round((now - _mtime(path)) / 60, 1),
            "transcript": str(path),
        })
    return out


# --- state (locked, atomic) -------------------------------------------------

def _defaults(s: dict) -> dict:
    for k, v in (("acked", []), ("stale_reported", []), ("parents", {}), ("parent_misses", {})):
        s.setdefault(k, v)
    return s


def read_state() -> dict:
    try:
        return _defaults(json.loads(STATE_FILE.read_text()))
    except (OSError, json.JSONDecodeError):
        return _defaults({})


@contextlib.contextmanager
def locked_state():
    """Read-modify-write under an exclusive lock; write via temp file + rename."""
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE.with_suffix(".lock"), "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        s = read_state()
        yield s
        tmp = STATE_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(s, indent=2))
        os.replace(tmp, STATE_FILE)


def threshold(a) -> int:
    if a.threshold:
        return a.threshold
    return int(read_state().get("threshold") or os.environ.get("CONTEXT_THRESHOLD") or DEFAULT_THRESHOLD)


# --- commands ---------------------------------------------------------------

def cmd_status(a) -> None:
    th = threshold(a)
    with locked_state() as st:
        rows = agents(find_session(a.session, a.cwd), st)
        acked = set(st["acked"])
    rows = [dict(r, handed_off=r["id"] in acked) for r in rows if not (a.live and r["id"] in acked)]
    if a.json:
        for r in rows:
            print(json.dumps(r))
        return
    names = {r["id"]: r["name"] for r in rows}
    print(f"threshold {th:,}")
    print(f"{'id':<18} {'parent':<12} {'d':>1} {'tokens':>9} {'%':>4} {'idle':>6}  name")
    for r in rows:
        pct = 100 * r["tokens"] // th
        flag = " (handed off)" if r["handed_off"] else ""
        parent = names.get(r["parent"], r["parent"])[:12]
        print(f"{r['id']:<18} {parent:<12} {r['depth']:>1} {r['tokens']:>9,} {pct:>3}% "
              f"{r['idle_mins']:>5}m  {r['name'][:40]}{flag}")


def _brief(r: dict) -> dict:
    """Only what the supervisor needs to act on: no paths, no types."""
    return {k: r[k] for k in ("id", "name", "parent", "tokens")}


def cmd_watch(a) -> None:
    main = find_session(a.session, a.cwd)
    th = threshold(a)
    deadline = time.time() + a.max_wait
    while True:
        with locked_state() as st:  # re-read every poll, so acks made meanwhile are seen
            rows = agents(main, st)
            acked = set(st["acked"])
            events = []
            for r in rows:
                if r["id"] in acked or (r["id"] == "main" and not a.include_main):
                    continue
                if r["tokens"] >= th:
                    events.append({"event": "threshold", **_brief(r)})
                elif a.stale_mins and r["id"] != "main":
                    if r["idle_mins"] >= a.stale_mins:
                        if r["id"] not in st["stale_reported"]:
                            st["stale_reported"].append(r["id"])
                            events.append({"event": "stale", **_brief(r)})
                    elif r["id"] in st["stale_reported"]:
                        st["stale_reported"].remove(r["id"])  # active again: can go stale again
        if events:
            # Report everything over the line at once: parallel workers tend to cross together.
            for e in events:
                print(json.dumps(e), flush=True)
            return
        if time.time() >= deadline:
            print(json.dumps({"event": "heartbeat", "agents": len(rows)}), flush=True)
            sys.exit(2)
        time.sleep(a.interval)


def cmd_ack(a) -> None:
    with locked_state() as st:
        for aid in a.ids:
            if aid not in st["acked"]:
                st["acked"].append(aid)
    print(f"acked: {', '.join(a.ids)}")


def cmd_verify(a) -> None:
    p = Path(a.path)
    if not p.is_absolute():
        p = BASE_DIR / p
    p = p.resolve()
    if not p.is_relative_to(BASE_DIR):
        sys.exit("handoff path is outside the project dir")
    problems = []
    if not p.is_file():
        problems.append("missing")
    else:
        if a.since and p.stat().st_mtime < a.since:
            problems.append(f"stale (written {int(a.since - p.stat().st_mtime)}s before --since)")
        text = p.read_text()
        problems += [f"no '{s}'" for s in HANDOFF_SECTIONS if s not in text]
        if len(text.strip().split("\n")) < 6:
            problems.append("too short")
    print(json.dumps({"path": str(p), "ok": not problems, "problems": problems}))
    sys.exit(0 if not problems else 1)


LEDGER_HEAD = ("# Ledger: decisions (D) and questions (Q). Append one line each. Read with grep.\n"
               "# status: ok | ⚠broken | ⚠suspect | open | blocking | answered: <text>\n\n"
               "| id | item | entry | choice | assumes | deps | status |\n"
               "|---|---|---|---|---|---|---|\n")


def cmd_init(a) -> None:
    root = STATE_FILE.parent
    for d in ("handoffs", "roles", "templates"):
        (root / d).mkdir(parents=True, exist_ok=True)
    copies = [(root / "ledger.md", None),
              (root / "roles" / "worker.md", TEMPLATES / "worker.md"),
              (root / "roles" / "orchestrator.md", TEMPLATES / "orchestrator.md"),
              (root / "templates" / "handoff.md", TEMPLATES / "handoff.md")]
    for dest, src in copies:
        if dest.exists():
            continue
        dest.write_text(LEDGER_HEAD if src is None else src.read_text())
        print(f"created {dest.relative_to(BASE_DIR)}")
    with locked_state() as st:
        if a.threshold:
            st["threshold"] = a.threshold
        print(f"threshold {st.get('threshold') or DEFAULT_THRESHOLD:,}")


def main() -> None:
    global STATE_FILE, BASE_DIR
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--session", help="session id (default: $CLAUDE_CODE_SESSION_ID, else newest for --cwd)")
    p.add_argument("--cwd", default=os.getcwd(), help="dir the session started in (default: cwd)")
    p.add_argument("--dir", default=os.environ.get("SUPERVISE_DIR") or os.getcwd(),
                   help="project dir holding .scratch/ (default: $SUPERVISE_DIR, else cwd)")
    p.add_argument("--threshold", type=int, help="tokens (default: value saved by init, else 500000)")
    sub = p.add_subparsers(dest="cmd", required=True)
    i = sub.add_parser("init")
    i.add_argument("--threshold", type=int, dest="init_threshold")
    s = sub.add_parser("status")
    s.add_argument("--json", action="store_true")
    s.add_argument("--live", action="store_true", help="hide handed-off agents")
    w = sub.add_parser("watch")
    w.add_argument("--interval", type=int, default=60, help="seconds between polls")
    w.add_argument("--max-wait", type=int, default=3600, help="seconds before a heartbeat exit")
    w.add_argument("--stale-mins", type=float, default=0, help="report an agent idle this long (0 = off)")
    w.add_argument("--include-main", action="store_true", help="also report the supervisor itself")
    k = sub.add_parser("ack")
    k.add_argument("ids", nargs="+")
    v = sub.add_parser("verify-handoff")
    v.add_argument("path")
    v.add_argument("--since", type=float, default=0, help="epoch seconds (`date +%%s`); file must be newer")
    a = p.parse_args()
    if a.cmd == "init" and a.init_threshold:
        a.threshold = a.init_threshold
    BASE_DIR = Path(a.dir).resolve()
    STATE_FILE = BASE_DIR / ".scratch" / "supervisor-state.json"
    {"status": cmd_status, "watch": cmd_watch, "ack": cmd_ack, "verify-handoff": cmd_verify,
     "init": cmd_init}[a.cmd](a)


if __name__ == "__main__":
    main()
