"""Tests for context_watch.py against a fake three-layer session.

    main (supervisor) --T1--> orchestrator (depth 1) --T2--> worker-1 (depth 2)
                                                     --T3--> worker-2 (depth 2)

Run (from the skill folder): python3 -m pytest -q scripts
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

SCRIPT = Path(__file__).with_name("context_watch.py")
SESSION = "11111111-2222-3333-4444-555555555555"


def line(kind, usage=None, tool_use_id=None):
    msg = {"role": kind, "content": []}
    if usage:
        msg["usage"] = usage
    if tool_use_id:
        msg["content"] = [{"type": "tool_use", "id": tool_use_id, "name": "Agent", "input": {}}]
    return json.dumps({"type": kind, "message": msg})


def usage(n):
    return {"input_tokens": 10, "cache_creation_input_tokens": 1000, "cache_read_input_tokens": n - 1010,
            "output_tokens": 50}


def build(tmp: Path, w1=120_000, w2=30_000, orch=80_000) -> tuple[Path, Path]:
    cfg = tmp / "cfg"
    proj = cfg / "projects" / "-work"
    sub = proj / SESSION / "subagents"
    sub.mkdir(parents=True)
    (proj / f"{SESSION}.jsonl").write_text(
        "\n".join([line("user"), line("assistant", usage(50_000), tool_use_id="T1")]) + "\n")
    agents = {
        "orch": ("orchestrator", "T1", 1, [line("assistant", usage(orch), tool_use_id="T2"),
                                           line("assistant", usage(orch), tool_use_id="T3")]),
        "w1": ("worker-1", "T2", 2, [line("assistant", usage(w1))]),
        "w2": ("worker-2", "T3", 2, [line("assistant", usage(w2))]),
    }
    for aid, (desc, tid, depth, lines) in agents.items():
        (sub / f"agent-{aid}.jsonl").write_text("\n".join(lines) + "\n")
        (sub / f"agent-{aid}.meta.json").write_text(json.dumps(
            {"agentType": "general-purpose", "description": desc, "toolUseId": tid, "spawnDepth": depth}))
    work = tmp / "work"
    work.mkdir()
    return cfg, work


def run(cfg, work, *args, check=True):
    env = {**os.environ, "CLAUDE_CONFIG_DIR": str(cfg)}
    env.pop("CLAUDE_CODE_SESSION_ID", None)
    r = subprocess.run([sys.executable, str(SCRIPT), "--cwd", "/work", *args],
                       cwd=work, env=env, capture_output=True, text=True)
    if check and r.returncode not in (0, 2):
        raise AssertionError(r.stderr)
    return r


def rows(r):
    return {d["id"]: d for d in map(json.loads, r.stdout.splitlines())}


def test_parents_resolve_at_every_depth(tmp_path):
    cfg, work = build(tmp_path)
    got = rows(run(cfg, work, "status", "--json"))
    assert got["orch"]["parent"] == "main"
    assert got["w1"]["parent"] == "orch"
    assert got["w2"]["parent"] == "orch"
    assert got["w1"]["depth"] == 2 and got["w1"]["tokens"] == 120_000


def test_watch_reports_every_agent_over_threshold(tmp_path):
    cfg, work = build(tmp_path, w1=120_000, w2=110_000, orch=80_000)
    r = run(cfg, work, "--threshold", "100000", "watch", "--interval", "1", "--max-wait", "5")
    events = rows(r)
    assert r.returncode == 0
    assert set(events) == {"w1", "w2"}
    assert all(e["event"] == "threshold" and e["parent"] == "orch" for e in events.values())


def test_ack_hides_agent_and_heartbeat_follows(tmp_path):
    cfg, work = build(tmp_path)
    run(cfg, work, "ack", "w1")
    r = run(cfg, work, "--threshold", "100000", "watch", "--interval", "1", "--max-wait", "1")
    assert r.returncode == 2
    assert json.loads(r.stdout)["event"] == "heartbeat"


def test_verify_handoff(tmp_path):
    cfg, work = build(tmp_path)
    good = work / "h.md"
    good.write_text("\n".join(["# Handoff", "## State", "x", "## Next", "#A1",
                               "## Verify first", "D1@w1"]))
    assert run(cfg, work, "verify-handoff", str(good), check=False).returncode == 0
    r = run(cfg, work, "verify-handoff", str(good), "--since", str(time.time() + 60), check=False)
    assert r.returncode == 1 and "stale" in r.stdout
    bad = work / "bad.md"
    bad.write_text("## State\nonly\n")
    r = run(cfg, work, "verify-handoff", str(bad), check=False)
    assert r.returncode == 1 and "Next" in r.stdout
    assert run(cfg, work, "verify-handoff", str(work / "nope.md"), check=False).returncode == 1


def test_init_creates_ledger_roles_and_templates(tmp_path):
    cfg, work = build(tmp_path)
    run(cfg, work, "init")
    sc = work / ".scratch"
    assert "| id | item | entry |" in (sc / "ledger.md").read_text()
    for f in ("roles/worker.md", "roles/orchestrator.md", "templates/handoff.md"):
        assert (sc / f).is_file(), f
    (sc / "ledger.md").write_text((sc / "ledger.md").read_text() + "| Q1@a | #A1 | x | y | — | — | open |\n")
    run(cfg, work, "init")  # must not overwrite
    assert "Q1@a" in (sc / "ledger.md").read_text()


def test_init_stores_threshold_for_later_commands(tmp_path):
    cfg, work = build(tmp_path, w1=120_000)
    run(cfg, work, "init", "--threshold", "100000")
    r = run(cfg, work, "watch", "--interval", "1", "--max-wait", "1")
    assert r.returncode == 0 and "w1" in rows(r)


def test_dir_flag_shares_state_across_cwds(tmp_path):
    cfg, work = build(tmp_path)
    other = tmp_path / "elsewhere"
    other.mkdir()
    env = {**os.environ, "CLAUDE_CONFIG_DIR": str(cfg)}
    env.pop("CLAUDE_CODE_SESSION_ID", None)
    subprocess.run([sys.executable, str(SCRIPT), "--cwd", "/work", "--dir", str(work), "ack", "w1"],
                   cwd=other, env=env, check=True, capture_output=True)
    assert "w1" in (work / ".scratch/supervisor-state.json").read_text()


def test_ack_during_watch_is_not_lost(tmp_path):
    cfg, work = build(tmp_path, w1=30_000)
    env = {**os.environ, "CLAUDE_CONFIG_DIR": str(cfg)}
    env.pop("CLAUDE_CODE_SESSION_ID", None)
    proc = subprocess.Popen([sys.executable, str(SCRIPT), "--cwd", "/work", "--threshold", "100000",
                             "watch", "--interval", "1", "--max-wait", "4"],
                            cwd=work, env=env, stdout=subprocess.PIPE, text=True)
    time.sleep(1.5)
    run(cfg, work, "ack", "w1")
    proc.wait(timeout=10)
    assert "w1" in json.loads((work / ".scratch/supervisor-state.json").read_text())["acked"]


def test_unicode_separators_and_zero_usage_lines(tmp_path):
    cfg, work = build(tmp_path)
    t = cfg / "projects/-work" / SESSION / "subagents/agent-w2.jsonl"
    real = json.dumps({"type": "assistant", "message": {"content": "a b", "usage": usage(150_000)}},
                      ensure_ascii=False)
    zero = line("assistant", {"input_tokens": 0, "cache_creation_input_tokens": 0,
                              "cache_read_input_tokens": 0})
    t.write_text(real + "\n" + zero + "\n")
    assert rows(run(cfg, work, "status", "--json"))["w2"]["tokens"] == 150_000
