# Scope

Decompose before building, so the human and [[run]] see the same parts, gaps and assumptions.

## Decompose

- Intent: goal, inputs, outputs, transforms between
- Expand compressed steps: "scrape sites" = read URLs → fetch → parse → extract;
  Hidden sub-flow → `subgraph`
- Type every edge: `List[URL]`, `{title, body, url}`, `File(json)`; mark inferred
- Flag: config, fan-out, LLM calls, external services, human gates
- Ops are nodes, not footnotes: incremental runs (default if repeated), rate limits, batching, retries, caching
- SIPOC check: every supplier, hidden input (creds, approvals, triggers), output (incl. side effects), customer + the format they need;
  Nothing changed after the check: you rushed it

## Write

`<name>.mermaid`: `flowchart TD`. Main flow = spine = the critical path in [[run]].
```mermaid
id(Step)  id([I/O]):::io  id{Decision?}  id[/LLM: task/]:::llm  id[Config: x]:::config
id[(Store)]  id[[API: svc]]:::external   A -->|List[URL]| B   subgraph ids in snake_case
classDef llm fill:#a78bfa,stroke:#7c3aed,color:#fff
classDef config fill:#fbbf24,stroke:#d97706,color:#000
classDef external fill:#60a5fa,stroke:#2563eb,color:#fff
classDef io fill:#34d399,stroke:#059669,color:#fff
```
(`id[[API: svc]]` above is Mermaid syntax, not a module link.)

`<name>_decisions.md` (read first):
- What: 2–3 sentences
- SIPOC: 1 row per phase
- Assumptions, as questions ("Only new items each run — right?")
- Open questions, most blocking first
- Dependencies, as a checklist
- Not included + why

`<name>_data.md`: every shape crossing an edge, flow order, 1 line per field, `(inferred)` marked

## Out → [[run]] or [[supervise]]

- Spine → first items in `plan.md`
- Assumptions → `D` rows; open questions → `Q` rows with a reversible default (§Ledger)
