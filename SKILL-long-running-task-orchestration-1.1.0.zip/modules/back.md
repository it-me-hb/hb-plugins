# Back

- Brief: show the last return brief (§Return brief);
  none: rebuild it from `plan.md` ticks + ledger + `git log --oneline`
- Questions: [[decide#human-back]]
- Broken: `grep '⚠' .scratch/ledger.md`
  each: untick its item in `plan.md`, or add `#<item>-fix`
- [[supervise]] still running: send `ANSWERS` to the orchestrator (no nesting: to each worker whose `Q` row was answered)
- Ask: go again? → [[run]] | [[supervise]] | stop

## Out

```text
Answered: <n> (<n> changed a default)
Reopened: <#ids>
Next: <the run you're starting, or stop>
```
