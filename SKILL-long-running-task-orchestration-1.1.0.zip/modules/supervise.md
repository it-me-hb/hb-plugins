# Supervise

Long unattended multi-agent work. Run it like a team: set roles, managers, written handovers, shared knowledge records.

You = supervisor. Never read code, plans or reports. Watch, route, restart.
- Every agent's final reply = exactly `Complete <name>`. Everything else → files.
- Prioritise counts over contents (closer to a PM): `W status`, `grep -c`, grep for open / blocking rows
- All state in files: your own compaction loses nothing

`W` = `python3 <skill>/scripts/context_watch.py`, run from the project root (or set `SUPERVISE_DIR`).
`<skill>` = the folder that holds this skill's SKILL.md.

Spawned agents don't load this skill. `W init` copies `templates/orchestrator.md` and `templates/worker.md` into `.scratch/roles/`; those are their whole instructions.

## Setup

- `W init --threshold 500000` → `.scratch/` with `ledger.md`, `handoffs/`, `roles/`, `templates/`
- Write `plan.md` (§State) with `@owner`, `needs:` and `tier:` on each line; agents grep their own lines, never read the whole plan
- Pick a framework (default kanban), fill the placeholders in `.scratch/roles/orchestrator.md`
- Spawn: description `orchestrator`, prompt `Read .scratch/roles/orchestrator.md`
- Watcher in background (Monitor): `W watch --stale-mins 30`

## Models

Match model + effort to the role. Biggest-for-everything wastes tokens; check which models and effort levels you can spawn with.

- Supervisor: reads counts, thinks little → stays light
- Orchestrator: sequencing, ⚠ triage, reassigning → most capable, high effort
- Workers: default mid-tier, normal effort
  mechanical (renames, formatting, fixtures, docs from code) → `tier:light`: smallest, low effort
  hard (unclear spec, cross-cutting) → `tier:heavy`: most capable, high effort
- Escalate: item fails or hands off twice → next tier or effort up, log a `D` row
- Never step down on an item with a `⚠` row: a cheaper model is likelier to miss why it broke
- Threshold must fit the smallest context window in use

## Frameworks

Take the structure, skip the ceremonies (standups, estimates, sprint planning).

| | Use for | Shape |
|---|---|---|
| kanban | fan-out, testing, most builds | pull next unblocked item, WIP limit, done = tests pass + ticked |
| scrum | long builds with review points | round = sprint, review each round, handoff = retro |
| dmaic | debugging, improving a process | measure before changing, control check at end |

## Loop

Watcher exits with 1 JSON line per agent needing attention. Handle every line, re-arm.

threshold:
  `T=$(date +%s); W ack <id>`
  send `HANDOFF .scratch/handoffs/<name>.md` (agent follows [[handoff]] via its role file)
  on `Complete <name>`: `W verify-handoff <path> --since $T`; fails twice → rename `.failed.md`
  restart: parent = `main` → respawn from its role file
           parent = other → tell parent `<name> handed off, restart it`
           parent = `?` → wait one poll
stale:
  `grep '@<name>' plan.md`; no ticks moved → restart it
heartbeat (exit 2):
  `grep -E '\| (blocking|open) \|' .scratch/ledger.md`; new blocking → push to user

## No nesting?

Spawn workers yourself, keep `.scratch/agents.json` as `{name: id}`. Orchestrator messages workers by id, re-reads the file each round. Send it `round` between watcher events.

## End

Plan done: stop watcher → return brief (§Return brief), ⚠ + open rows pulled by grep. Human returns → [[back]].
