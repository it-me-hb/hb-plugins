# Route

Find the shortest route that works and that you can explain.

- Who uses the output, and what do they do with it?
  Unknown: find out first. Nothing else until then.
- Trace the whole flow: step before → this step → step after;
  Why does the work arrive in this form?
  5 teams fixing 5 steps = 5 automations, not 1
- Act upstream: fix the source query or sender, not the cleanup. Best step = deleted step.
- Scope = smallest that holds the whole problem AND has someone who can approve it
- Span sets form:
  1 owner: disposable script, macro, whatever's to hand
  > 1 owner: own identity + access, so it outlives whoever set it up
- Source of truth exists in the wrong format? Re-project it, don't rebuild.
- Cut anything that doesn't reach the output
- Every step observable: you know which one to open when it breaks
- Say the plan in plain English (ASD-STE100). If it doesn't survive it isn't settled.

## Out → [[decide#human-here]]

```text
For: <who> -> <what they do with it>
Shape: <agreed route, 1–3 lines>
Ruled out: <option — why>
```
