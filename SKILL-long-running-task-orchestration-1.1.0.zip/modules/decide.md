# Decide

Procedures for decision making.
**Human here → ask. Human away → pick.**
Read "Every decision" plus your own section only.

## Every decision

- Frame: 1 sentence, what's being decided
- Answerable from code / docs / data: answer it yourself, it isn't a decision
- Options: 2–4, 1 line each
- Recommend: winner + what tipped it (value, effort, reversibility, what's waiting on it; rough read, not numbers)
- Reversibility sets depth:
  minutes to undo: pick, don't log
  hours: quick pass, log
  days: every step, log
  never (prod, data deletion, external comms): every step, and only a human may say yes
- Log: `D` row for a decision, `Q` row for one the human still owes (§Ledger)

## Human here

Human in the loop (`grill`: "grill me", "poke holes"). Spend their judgement only on what only they can decide.

- One question at a time: question + 2-4 reasonable options + recommendation + 1-line why
- Order: highest-leverage decision first, then what depends on it
- Stop: after 10 questions, or sooner when nothing high-leverage is left
- Out:
  ```text
  | # | Question | Decision | Assumes |
  |---|---|---|---|

  Open: <items>
  Next: [[scope]] (many moving parts) | [[run]] (fits in your head)
  ```
- Next = [[run]] or [[supervise]]: each decision → `D` row, each open item → `Q` row with a default

## Human away

Human out of the loop (`decide`). Decide, log why, move on; don't wait.

- Pick the recommendation. Tie: whatever unblocks most. "Decide later" only if nothing waits on it.
- Needs the human, safe default exists: take it, `Q` row `open` with the default in `choice`, keep going
- No safe default, or irreversible: `Q` row `blocking`, don't do it, skip, keep going

## Human back

Human returns to the loop, run from [[back]]. Settle what the run deferred.

- Queue: `grep -E '\| (blocking|open) \|' .scratch/ledger.md`, blocking first
- One at a time: question + default used + your recommendation now
- Write the answer: status → `answered: <text>`
- Answer ≠ default: propagate (§Ledger)
