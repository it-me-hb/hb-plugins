# Handoff

Next agent continues without re-deriving anything or reading anything it doesn't need.

## Write

- Path: the one you were given, else `.scratch/handoffs/<name>.md`
- First tick everything finished in `plan.md`: ticks = restart point
- Fill `<skill>/templates/handoff.md` (or `.scratch/templates/handoff.md` if `W init` ran) into that path:
  State (3–6 lines: exists, half-done, broken) · Next (#ids in order) · Verify first (ledger ids only) · Greps
- Ledger rows: point by id, never copy. Ledger = record, handoff = index. No narrative.
- Asked by a supervisor (`HANDOFF <path>`): write → reply `Complete <name>` → stop

## Resume

- Read the handoff, run its greps
- Each Verify-first id: still true? → `ok` | `⚠broken` + propagate (§Ledger)
- Answers: `grep 'Q[0-9]*@<name>' .scratch/ledger.md`
- Rename → `<name>.<YYYYMMDD-HHMM>.resumed.md` (never resume twice: two agents would build the same items; never from `.failed.md`)
- Continue from Next, in whatever mode you were in ([[run]] or a [[supervise]] role)
