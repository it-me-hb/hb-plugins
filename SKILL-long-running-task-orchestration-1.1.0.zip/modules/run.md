# Run

An unattended agent under time pressure.
Make something working and touchable over just documentation.

## Start

- Task unclear: ask once. No reply (human already away): take the most reasonable reading, state it at the top of `plan.md`, log a `Q` row `open`, start.
- Runway:
  given ("back in 2h", "20 minutes") → use it
  not given, calendar tools available → until the next free slot ("back to back" = until the meetings end)
  smash-it with none → this session
  otherwise → ask; no reply → 60 minutes, logged as a `Q` row `open`
- Record start time, work out end time
- Size: 20m = 1 deliverable; 1–2h = connected feature; 4–8h = small product
- Plan = `plan.md` (§State). [[scope]] ran: its spine = first items
- More than one context window, or it fans out → [[supervise]] instead

## Loop

- Spine first: thinnest end-to-end slice, then widen by value;
  Short on time: cut edges, never spine
- Each item: build → test → tick → commit `#A1: <what>` (non-code work: draft → check → tick)
- Then review → improve → next piece → repeat
- Fork → [[decide#human-away]]. Blocker → `Q` row, skip it, keep working on what you can
- Each item or stage change: check the clock; `grep '@<you>' .scratch/ledger.md` (⚠ rows? answered Qs?)
- Avoid: doing one thing and waiting, wandering off task, stopping early

## End

- Runs dry before end time: be ambitious — review, test, fix, polish, document, extend. Keep working.
- At or past end time: stop. Overshoot is fine, stopping early is not.
- Work left → [[handoff]] first
- Return brief (§Return brief)
