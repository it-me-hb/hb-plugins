# Handoff: <name> — <date time>

## State
<what exists, what's half-done, what's broken. 3–6 lines.>

## Next
<items left, in order. One line each, by #id.>

## Verify first
<ledger ids whose assumptions aren't confirmed yet. Ids only.>

## Greps
grep '@<name>' plan.md
grep '@<name>' .scratch/ledger.md
